import { useState } from "react";
import UploadScreen from "./components/UploadScreen";
import ProcessingScreen from "./components/ProcessingScreen";
import Papa from "papaparse";

export default function App() {
  const [rows, setRows] = useState([]);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleFileUpload = (file) => {
    Papa.parse(file, {
      complete: (results) => {
        const parsedRows = results.data
          .filter((row) => row.some((cell) => cell.trim() !== ""))
          .map((row, index) => ({
            id: index,
            raw: JSON.stringify(
              {
                row: index + 1,
                details: { Raw: row.join(", ") },
              },
              null,
              2
            ),
            data: row.join(", "),
            status: "pending",
            aiData: null,
          }));
        setRows(parsedRows);
        setIsProcessing(true);
      },
      error: (error) => {
        console.error("Error parsing CSV:", error);
        alert("Failed to parse CSV file.");
      },
    });
  };

  return (
    <div className="min-h-screen bg-gray-100 font-sans">
      {/* <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8 flex items-center">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-6 w-6 text-indigo-600 mr-2"
          >
            <path d="m10.5 19.5 1.8-1.8c.5-.5.4-1.3-.1-1.7l-2.4-2.4c-.4-.4-1.2-.5-1.7-.1L4.5 15.1c-.5.5-.4 1.3.1 1.7l2.4 2.4c.4.4 1.2.5 1.7.1zM8.2 11.2 3.1 6.1c-1-1-1.5-2.5-.2-3.8 1.4-1.4 3.6-.9 4.6.1l5.1 5.1" />
            <path d="m14 6 3.4-3.4c1-1 2.5-.9 3.5.1s.9 2.5-.1 3.5L17.5 9.5" />
            <path d="m18 12 -2.1-2.1c-.5-.5-1.3-.4-1.7.1l-2.4 2.4c-.4.4-.5 1.2-.1 1.7l1.8 1.8c.5.5 1.3.4 1.7-.1l2.4-2.4c.4-.4.5-1.2.1-1.7z" />
          </svg>
          <h1 className="text-xl font-semibold text-gray-800">
            Car Processing
          </h1>
        </div>
      </header> */}
      {/* <main className="py-8"> */}
      <main className="min-h-screen flex items-center justify-center">
        {!isProcessing ? (
          <UploadScreen onFileUpload={handleFileUpload} />
        ) : (
          <ProcessingScreen initialRows={rows} />
        )}
      </main>
    </div>
  );
}
